<?php if(isset($customer)): ?>
    <p>Mã khách hàng: <?php echo e($customer->customer_code); ?></p>
    <p>Số điện thoại: <?php echo e($customer->phone); ?></p>
    <p>Tên khách hàng: <?php echo e($customer->name); ?></p>
    <p>Điểm tích lũy: <?php echo e($customer->points); ?></p>
    <p>Hạng: <?php echo e($customer->rank); ?></p>
    <p>Số người đã giới thiệu: <?php echo e($customer->referrer_count); ?></p>
<?php else: ?>
    <p>Không tìm thấy khách hàng.</p>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/membership_source/resources/views/Customer/searchCustomer.blade.php ENDPATH**/ ?>